<?php
$nilai = ["72","65","73","78","75","74","90","81","87","65","55","69","72","78","79","91","100","40","67","77","86"];
// mencari nilai rata rata 
$jml = count($nilai);
$nilai_angka = 0;

foreach($nilai as $p){
    // echo $p."<br>";
    $nilai_angka += $p;
}
$rata_rata = $nilai_angka/$jml;


echo "<center><h1>Bagian 1 : PHP Dasar</h1></center>";
echo "<li>Nilai ujian sebuah kelas tersimpan dalam sebuah string berikut :</li> <br>
Nilai = 72 65 73 78 75 74 90 81 87 65 55 69 72 78 79 91 100 40 67 77 86  <br> <br>";

echo "&nbsp;&nbsp;1. Nilai rata rata = ". $rata_rata." <br>";
echo "&nbsp;&nbsp;2. Nilai tertinggi <br>";
echo "&nbsp;&nbsp;<i>Jawab :</i><br>";

arsort($nilai);
$i = 0;
foreach($nilai as $tertinggi){
    $i++;
   if($i <= 7){
        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ".$tertinggi."  ";
   }
}
echo " <br>";
sort($nilai);
echo "&nbsp;&nbsp;3. Nilai terendah  <br>";
echo "&nbsp;&nbsp;<i>Jawab :</i><br>";
$x = 0;
foreach($nilai as $terendah){
    $x++;
   if($x <= 7){
        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  ".$terendah."  ";
   }
}



echo " <br><br><br>
<li>Buatlah sebuah fungsi dalam PHP untuk menentukan jumlah huruf kecil dalam sebuah string.</li>";
echo "&nbsp;&nbsp;Contoh : bila fungsi diberikan input “TranSISI” maka akan menghasilkan output : “TranSISI” mengandung 3 buah huruf kecil. <br>";
echo "&nbsp;&nbsp;<i>Jawab :</i><br>";
$huruf = "TranSISI";
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ".strlen($huruf);

echo " <br><br><br>
<li>Buatlah sebuah fungsi dalam PHP untuk membentuk unigram, bigram, trigram dari sebuah string.</li>";
echo "&nbsp;&nbsp; “Jakarta adalah ibukota negara Republik Indonesia” <br>";
$text = "Jakarta adalah ibukota negara Republik Indonesia";
$text_input = explode(' ', $text);
echo "&nbsp;&nbsp;<i>Jawab :</i><br>";

$unigram = '';
foreach ($text_input as $item) {
    $unigram .= $item.', ';
}
$unigram = substr($unigram, 0, -2);
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Unigram : ".$unigram."<br> ";

$x = 0;
$bigram = '';
foreach ($text_input as $item) {
    if ($x < 1) {
        $bigram .= $item.' ';
        $x++;
    } else {
        $bigram .= $item.', ';
        $x = 0;
    }
}
$bigram = substr($bigram, 0, -2);
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; bigram : ".$bigram."<br> ";

$y = 0;
$trigram = '';
foreach ($text_input as $item) {
    if ($y < 2) {
        $trigram .= $item.' ';
        $y++;
    } else {
        $trigram .= $item.', ';
        $y = 0;
    }
}
$trigram = substr($trigram, 0, -2);
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; trigram : ".$trigram."<br> ";
////////////////////////////////////// bagian 2 /////////////////////////////////////
echo "<center><h1>Bagian 1 : PHP Dasar (2)</h1></center>";
////////////////////////////////////// bagian 3 /////////////////////////////////////
echo "<center><h1>Bagian 1 : PHP Dasar (3)</h1></center>";
echo " <br><br><br>
<li>Diketahui sebuah array berikut :</li>";
$arr = [
    ['f', 'g', 'h', 'i'],
    ['j', 'k', 'p', 'q'],
    ['r', 's', 't', 'u']
   ];

$fghi = '';

foreach ($arr as $key) {
        $fghi .= $key;
}
   $cari = array_search("fghi", $arr);
   echo "&nbsp;&nbsp;<i>Jawab :</i><br>";
   echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  ".$cari."<br> ";
?>